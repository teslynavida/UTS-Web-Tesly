<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="jquery.js"></script>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../css/login.css">

    <title>Buat Akun</title>
  </head>
  <body>
    
      <div class="container">
            <h4 class="text-center">BUAT AKUN</h4>
            <hr>
         

            <form action="import.php" method="post" onSubmit="return valdasi()">
            <div class="form-grup">
                    <label for="">Nama Akun</label>
                    <input type="text" name="nama" class="form-control" id="nama" placeholder="Masukan Nama">
                </div> 
                <div class="form-grup">
                    <label for="">Username</label>
                    <input type="text" name="username" class="form-control" id="username" placeholder="Masukan Username">
                </div> 
                <div class="form-grup">
                    <label for="">Password</label>
                    <input type="password" name="password" class="form-control" id="password" placeholder="Masukan password">
                    <input type="checkbox" onclick="myFunction()">Tampilkan Password
                    <script>
                      function myFunction() {
                          var x = document.getElementById("password");
                          if (x.type === "password") {
                              x.type = "text";
                          } else {
                              x.type = "password";
                          }
                      }
                  </script>
                </div>  
                 
                <button type="submit" class="btn btn-primary mt-3">Tambah</button>
                <!-- <button type="submit" class="btn black-wheat-and-mortarboard mt-3" ></button> -->
                <p><a href="index.php">Kembali</a></p>
            </form>
        </div>   
  </body>
</html>