<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BABA PARFUME</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:login.php?pesan=belum_login");
	}
	?>

<?php echo"<script>alert('Selamat, Anda Berhasil Login')</script>"?>
    <div class="container">
        <nav class="navbar"> 
        <div class="nav-brand">
            <span>BABA</span>parfume
        </div>
        <div class="nav-items">
            <ul class="nav-links">
                <li class="nav-link">
                    <a href="">Discover</a>
                 </li>
                <li class="nav-link">
                    <a href="">Product</a>
                </li>
                <li class="nav-link">
                    <a href="">Girls</a>
                </li>
                <li class="nav-link">
                    <a href="">Boys</a>
                </li>
                <li class="nav-link">
                    <a href="">Info</a>
                </li>
            </ul>
            <div class="nav-cta">
                <a href="logout.php" ><button class="btn-primary">
                    LOGOUT
                </button></a>
                </div>
            </div>
        </nav>  
    </div>


    <section class="discover">
        <div class="container">
            <div class="grid-2">
                <div class="tg-section">
                    <h1 class="heading-1">
                        find and get <br> your own smell
                    </h1>
                    <p class="text-light">
                        Rasakan kewangian dari baba parfume <br> dan sebarkan kewangiannya
                    </p>
                    <input type="text" placeholder="search parfume, boy, girl, produtcs..." class="search" 
                </input>
                </div>
                <div class="highlight-product">

                </div>
            </div>
        </div>
    </section>
</body>
</html>

