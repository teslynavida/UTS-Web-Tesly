<?php
session_start();
include "koneksi.php";

$username=$_POST["username"];
$nama=$_POST["nama"];
$password=$_POST["password"]; //untuk password digunakan enskripsi md5

$sql="insert into tb_tesly (username,nama,password) values
('$username','$nama','$password')";

//Mengeksekusi/menjalankan query diatas	
$hasil=mysqli_query($koneksi,$sql);

//Kondisi apakah berhasil atau tidak
if ($hasil) {
echo "<script>alert('akun telah di buat silahkan login')</script>";
echo "<meta http-equiv='refresh' content='1 url=index.php'>";
exit;
}
else {
echo "Gagal simpan data anggota";
exit;
}  

?>